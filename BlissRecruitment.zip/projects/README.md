# BlissRecruitmentApp

## Instructions

1. Clone this project using [git clone](https://github.com/paulojsmartins/BlissRecruitmentApp.git) or downloading this [release](https://github.com/paulojsmartins/BlissRecruitmentApp/releases/tag/v0.2).

2. Build it using ```C:\Windows\Microsoft.NET\Framework\v4.0.30319\msbuild.exe BlissRecruitmentApp.sln```

3. Run ```.\BlissRecruitmentApp\BlissRecruitmentApp\bin\Debug\BlissRecruitmentApp.exe```


Alternatively, open, build and run **.\BlissRecruitmentApp\BlissRecruitmentApp.sln** with Visual Studio.


