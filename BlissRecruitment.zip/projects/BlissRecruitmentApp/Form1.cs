﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;


namespace BlissRecruitmentApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.getHealth();
        }

        private void getHealth()
        {
            string text;
            
            string url = @"http://private-anon-1d5c7e984f-blissrecruitmentapi.apiary-mock.com/health";
            //ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072 | SecurityProtocolType.Tls;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.ContentType = "application/json; charset=utf-8";
            // using System.Net;
            //ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            // Use SecurityProtocolType.Ssl3 if needed for compatibility reasons
            var response = (HttpWebResponse)request.GetResponse();
            using (var sr = new StreamReader(response.GetResponseStream()))
            {
                text = sr.ReadToEnd();
            }

            var jss = new JavaScriptSerializer();
            var dict = jss.Deserialize<Dictionary<string, string>>(text);

            if (dict["status"] != "OK")
            {//Show Dialog to Retry connection
                DialogResult result1 = MessageBox.Show("Reconnect?",
                "Error Connecting to Bliss Recruitment App",
                MessageBoxButtons.YesNo);

                if (result1 == DialogResult.Yes)
                {
                    this.getHealth();
                }
            }
            else
            { //Health is "OK" 
                Form2 listScreen = new Form2(1, "");
                listScreen.Show();
                this.Hide();
            }
            
        }

        

    }
}
